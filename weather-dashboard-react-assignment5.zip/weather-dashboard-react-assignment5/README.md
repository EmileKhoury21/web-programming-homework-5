# React Weather Dashboard — Assignment 5

A rebuild of my Assignment 4 Weather Dashboard (plain HTML/CSS/JavaScript) as a
React application built with Vite. The UI is split into focused function
components, state is managed with `useState`, and weather data is fetched with
`useEffect`.

## Features

- Search any city (submit with the button or the Enter key)
- Input validation: empty searches show "Please enter a city name." and surrounding spaces are trimmed
- Welcome screen with one-click city suggestions (Beirut, Paris, Tokyo, New York)
- Current weather: city, country, local time, SVG weather icon, temperature, condition and today's high/low
- The main card's glow and icon color change with the weather (clear, cloudy, rain, snow, storm)
- Details: feels like, humidity, wind speed and rain
- 3-day forecast with weekday names, icons and high / low temperatures
- Two-column dashboard on desktop, single column on phones, with a short fade-in when results appear
- Loading state with a spinner, and the Search button is disabled while loading
- Friendly error messages ("City not found…" / "Couldn't reach the server…") with a **Retry** button
- Older requests are cancelled when a new search starts, so a slow response can never replace a newer result
- Responsive layout for desktop, tablet and phone

## Technologies

- **React 19**: function components and hooks (`useState`, `useEffect`)
- **Vite**: dev server and build tool
- **JavaScript (JSX)** and **CSS** (Flexbox, Grid, media queries) in a single stylesheet
- **Fira Sans** and **Fira Code** fonts (Google Fonts)
- **[lucide-react](https://lucide.dev/)**: SVG weather icons
- **[Open-Meteo API](https://open-meteo.com/)**: free and needs **no API key**
  - Geocoding: `https://geocoding-api.open-meteo.com/v1/search` (city → latitude/longitude)
  - Forecast: `https://api.open-meteo.com/v1/forecast` (current weather + 3-day forecast)

Because Open-Meteo needs no key, the project has no `.env` file and no secrets.

## Project structure

```
weather-app/
├── index.html              # HTML shell with the #root div
├── package.json
├── package-lock.json
├── vite.config.js
├── eslint.config.js
├── public/
│   └── favicon.svg
└── src/
    ├── main.jsx            # Mounts <App /> into #root
    ├── App.jsx             # Owns the state + the data-fetching effect
    ├── index.css           # All styles: color tokens, layout, components
    ├── api/
    │   └── weather.js      # fetchWeather(), getWeatherInfo(), getErrorMessage()
    └── components/
        ├── SearchBar.jsx
        ├── EmptyState.jsx
        ├── LoadingSpinner.jsx
        ├── ErrorMessage.jsx
        ├── WeatherCard.jsx
        ├── WeatherDetails.jsx
        └── Forecast.jsx
```

## Installation

Requires [Node.js](https://nodejs.org/) (version 20 or newer).

```bash
git clone <NEW_REPOSITORY_URL>
cd <PROJECT_FOLDER>
npm install
```

## Running the development server

```bash
npm run dev
```

Vite prints a local address in the terminal (usually `http://localhost:5173/`).
Open it in your browser.

## Building for production

```bash
npm run build
```

The optimized files are written to `dist/`. You can preview the build with `npm run preview`.

## React architecture

```
App                      state: query, weather, status, errorMessage  + useEffect
├── SearchBar            props: onSearch, isLoading      (own state: text, error)
├── EmptyState           props: onSelect
├── LoadingSpinner       props: city
├── ErrorMessage         props: message, onRetry
├── WeatherCard          props: weather
├── WeatherDetails       props: current
└── Forecast             props: daily
```

| Component | Responsibility |
|---|---|
| `App` | Holds the shared state, fetches the weather, decides which state to show |
| `SearchBar` | Controlled input + submit button, validates the input |
| `EmptyState` | Welcome panel with suggested cities, shown before the first search |
| `LoadingSpinner` | Spinner and "Loading <city>..." message |
| `ErrorMessage` | Friendly error message and a Retry button |
| `WeatherCard` | City, country, local time, icon, temperature, condition, today's high/low |
| `WeatherDetails` | The four stat tiles (feels like, humidity, wind, rain) |
| `Forecast` | The 3-day forecast list |

### Where the state lives

- **`App`** owns everything that more than one component needs:
  - `query`: the submitted search, stored as an object like `{ city: 'Beirut' }`. Every search or retry creates a *new* object, so the effect runs again even when the same city is searched twice.
  - `weather`: the fetched data.
  - `status`: `'idle' | 'loading' | 'success' | 'error'`.
  - `errorMessage`: the text shown by `ErrorMessage`.
- **`SearchBar`** owns `text` (what is being typed) and `error` (its validation message).
  No other component needs half-typed text, so it stays local. App only learns about the
  city when the form is submitted, which also means **no request is sent on each keystroke**.

### Where `useEffect` is used

`App.jsx` has one effect with the dependency array `[query]`:

1. It runs only when a new search is submitted, not on every render.
2. It creates an `AbortController` and calls `fetchWeather(city, signal)` inside an `async` function, using `try/catch` and a `response.ok` check.
3. Its **cleanup** function calls `controller.abort()`. If the user searches again before the previous
   request finishes, the old request is cancelled and can never overwrite the newer result.
   This also makes the effect safe under React StrictMode, which runs effects twice in development.

### Props and component communication

- **Data flows down:** App → `SearchBar` (`isLoading`), App → `WeatherCard` (`weather`),
  App → `Forecast` (`daily`), App → `LoadingSpinner` (`city`), App → `ErrorMessage` (`message`),
  App → `WeatherDetails` (`current`).
- **Events flow up through callbacks:** `SearchBar` calls `onSearch(city)`, `EmptyState` calls `onSelect(city)`
  (the same `handleSearch` function) and `ErrorMessage` calls `onRetry()`; all are functions defined in App that update App's state.

### Prop drilling

Every component receives its props **directly from App**: the data travels only one level.
There is no prop drilling at all, so React Context was not needed.

## Migration from the original project

The original app (Assignment 4) changed the page by hand: `getElementById`, `textContent`,
`innerHTML` for the forecast, and `style.display` to show or hide sections. In React:

- The HTML became JSX inside components, and values are inserted with `{ }`.
- Manual show/hide became **conditional rendering** (`status === 'success' && …`).
- The forecast loop with `createElement` became `daily.time.map(...)` with a `key`.
- `addEventListener` became `onSubmit` / `onClick` / `onChange` props.
- The fetching logic (`getJSON`, geocoding → forecast, weather-code → icon) was kept and moved to
  `src/api/weather.js`, with an abort `signal` added.
- The CSS (colors, font, cards, grid, breakpoint) was kept and simplified into one `index.css` file.
- Emoji icons were replaced with SVG icons from `lucide-react`, which look the same on every device.
- Small fix: weather codes 85–86 (snow showers) were shown as "Thunderstorm"; they now show "Snow showers".

## Author

- **Name:** <YOUR_NAME>
- **Course:** Web Programming, USJ 2026–2027
- **Assignment:** 5: React Multi-Component Application
- **Repository:** <NEW_REPOSITORY_URL>
