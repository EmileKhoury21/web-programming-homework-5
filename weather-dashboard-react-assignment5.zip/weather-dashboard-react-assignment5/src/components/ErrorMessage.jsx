import { CircleAlert, RotateCw } from 'lucide-react';

// Shown when the request fails. The Retry button asks the parent to search again.
function ErrorMessage({ message, onRetry }) {
  return (
    <section className="panel message error" role="alert">
      <CircleAlert size={32} aria-hidden="true" />
      <p>{message}</p>
      <button type="button" className="retry" onClick={onRetry}>
        <RotateCw size={18} aria-hidden="true" /> Retry
      </button>
    </section>
  );
}

export default ErrorMessage;
