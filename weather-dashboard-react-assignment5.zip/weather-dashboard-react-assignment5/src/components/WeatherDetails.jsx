import { Droplets, Thermometer, Umbrella, Wind } from 'lucide-react';

// Four stat tiles: feels like, humidity, wind and rain
function WeatherDetails({ current }) {
  const details = [
    { label: 'Feels like', value: Math.round(current.apparent_temperature) + '°C', Icon: Thermometer },
    { label: 'Humidity', value: current.relative_humidity_2m + '%', Icon: Droplets },
    { label: 'Wind', value: current.wind_speed_10m + ' km/h', Icon: Wind },
    { label: 'Rain', value: current.precipitation + ' mm', Icon: Umbrella },
  ];

  return (
    <ul className="details">
      {details.map(({ label, value, Icon }) => (
        <li className="panel tile" key={label}>
          <p className="eyebrow">
            <Icon size={16} aria-hidden="true" /> {label}
          </p>
          <p className="tile-value mono">{value}</p>
        </li>
      ))}
    </ul>
  );
}

export default WeatherDetails;
