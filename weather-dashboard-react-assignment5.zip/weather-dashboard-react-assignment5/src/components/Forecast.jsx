import { getDayName, getWeatherInfo } from '../api/weather.js';

// The 3-day forecast: one row per day
function Forecast({ daily }) {
  return (
    <section className="panel forecast">
      <h3 className="eyebrow">3-day forecast</h3>
      <ul>
        {daily.time.map((date, i) => {
          const { label, Icon } = getWeatherInfo(daily.weather_code[i]);
          const max = Math.round(daily.temperature_2m_max[i]);
          const min = Math.round(daily.temperature_2m_min[i]);

          return (
            <li key={date} className="day">
              <strong>{i === 0 ? 'Today' : getDayName(date)}</strong>
              <span className="day-sky muted">
                <Icon size={24} strokeWidth={1.5} aria-hidden="true" /> {label}
              </span>
              <span className="mono">
                {max}° <span className="muted">/ {min}°</span>
              </span>
            </li>
          );
        })}
      </ul>
    </section>
  );
}

export default Forecast;
