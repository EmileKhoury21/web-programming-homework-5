import { MapPin } from 'lucide-react';
import { getWeatherInfo } from '../api/weather.js';

// The main card: place, local time, temperature, condition and today's high/low
function WeatherCard({ weather }) {
  const { name, country, current, daily } = weather;
  const { label, Icon, sky } = getWeatherInfo(current.weather_code);

  const localTime = new Date(current.time).toLocaleString('en-US', {
    weekday: 'long',
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <section className="panel hero" data-sky={sky}>
      <div className="hero-top">
        <div>
          <h2>{name}</h2>
          <p className="muted place">
            <MapPin size={16} aria-hidden="true" /> {country}
          </p>
        </div>
        <p className="mono muted">{localTime}</p>
      </div>

      <div className="hero-main">
        <p className="temp">{Math.round(current.temperature_2m)}°</p>
        <Icon className="sky-icon" size={112} strokeWidth={1.25} aria-hidden="true" />
      </div>

      <p className="condition">{label}</p>
      <p className="mono muted">
        H {Math.round(daily.temperature_2m_max[0])}° · L {Math.round(daily.temperature_2m_min[0])}°
      </p>
    </section>
  );
}

export default WeatherCard;
