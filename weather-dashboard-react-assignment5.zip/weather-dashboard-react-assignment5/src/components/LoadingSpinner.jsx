import { LoaderCircle } from 'lucide-react';

// Shown while the weather request is in progress
function LoadingSpinner({ city }) {
  return (
    <section className="panel message" role="status">
      <LoaderCircle className="spin" size={32} aria-hidden="true" />
      <p>Loading weather for {city}...</p>
    </section>
  );
}

export default LoadingSpinner;
