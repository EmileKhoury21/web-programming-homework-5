import { Globe } from 'lucide-react';

const SUGGESTIONS = ['Beirut', 'Paris', 'Tokyo', 'New York'];

// Welcome panel shown before the first search, with one-click city suggestions
function EmptyState({ onSelect }) {
  return (
    <section className="panel empty">
      <Globe className="empty-icon" size={56} strokeWidth={1.25} aria-hidden="true" />
      <h2>Search any city in the world</h2>
      <p className="muted">Live conditions and a 3-day forecast. Try one of these:</p>
      <div className="chips">
        {SUGGESTIONS.map((city) => (
          <button key={city} type="button" className="chip" onClick={() => onSelect(city)}>
            {city}
          </button>
        ))}
      </div>
    </section>
  );
}

export default EmptyState;
