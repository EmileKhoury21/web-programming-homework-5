import { useEffect, useState } from 'react';
import { CloudSun } from 'lucide-react';
import { fetchWeather, getErrorMessage } from './api/weather.js';
import SearchBar from './components/SearchBar.jsx';
import EmptyState from './components/EmptyState.jsx';
import LoadingSpinner from './components/LoadingSpinner.jsx';
import ErrorMessage from './components/ErrorMessage.jsx';
import WeatherCard from './components/WeatherCard.jsx';
import WeatherDetails from './components/WeatherDetails.jsx';
import Forecast from './components/Forecast.jsx';

function App() {
  // The submitted search, e.g. { city: 'Beirut' }. A new object on every
  // search/retry, so the effect re-runs even when the city name is the same.
  const [query, setQuery] = useState(null);
  const [weather, setWeather] = useState(null);
  // 'idle' | 'loading' | 'success' | 'error'
  const [status, setStatus] = useState('idle');
  const [errorMessage, setErrorMessage] = useState('');

  function handleSearch(city) {
    setQuery({ city });
    setStatus('loading');
  }

  function handleRetry() {
    setQuery({ city: query.city });
    setStatus('loading');
  }

  // Fetch the weather whenever a new query is submitted
  useEffect(() => {
    if (query === null) return;

    // Lets us cancel this request if a newer search starts before it finishes
    const controller = new AbortController();

    async function loadWeather() {
      try {
        const data = await fetchWeather(query.city, controller.signal);
        setWeather(data);
        setStatus('success');
      } catch (err) {
        // Cancelled on purpose by the cleanup below: ignore it
        if (err.name === 'AbortError') return;
        setErrorMessage(getErrorMessage(err));
        setStatus('error');
      }
    }

    loadWeather();

    // Cleanup: runs before the next search (and when the app unmounts)
    return () => controller.abort();
  }, [query]);

  return (
    <>
      <header className="topbar">
        <p className="brand">
          <CloudSun size={22} aria-hidden="true" /> WEATHER <span>APP</span>
        </p>
      </header>

      <main className="app">
        <section className="intro">
          <h1>Check the weather anywhere</h1>
          <SearchBar onSearch={handleSearch} isLoading={status === 'loading'} />
        </section>

        {status === 'idle' && <EmptyState onSelect={handleSearch} />}
        {status === 'loading' && <LoadingSpinner city={query.city} />}
        {status === 'error' && (
          <ErrorMessage message={errorMessage} onRetry={handleRetry} />
        )}
        {status === 'success' && (
          <div className="dashboard">
            <WeatherCard weather={weather} />
            <WeatherDetails current={weather.current} />
            <Forecast daily={weather.daily} />
          </div>
        )}
      </main>

      <footer className="footer muted">
        Weather data by <a href="https://open-meteo.com/">Open-Meteo</a>
      </footer>
    </>
  );
}

export default App;
